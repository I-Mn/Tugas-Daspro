"""
Nama: Kautsar Muhammad Mizan
Kelas: 1C
NIM: 2404073
"""
jakarta = (-6.2088, 106.8456)
bandung = (-6.9175, 107.6191)
surabaya = (-7.2575, 112.7521)
print ("Lokasi Bandung: ", bandung)
Lokasi = jakarta,bandung,surabaya
print ("Jumlah lokasi tersimpan: ", len(Lokasi))