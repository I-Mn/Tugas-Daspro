"""
Nama: Kautsar Muhammad Mizan
Kelas: 1C
NIM: 2404073
"""
nilai = [88, 75, 63, 97, 82, 74, 91, 80, 81, 63]
print("Nilai maksimum:", max(nilai))
print("Nilai minimum:", min(nilai))
print("Nilai rata rata:", sum(nilai)/len(nilai))
nilai.sort()
print ("Nilai terbesar kedua: ", nilai[8])