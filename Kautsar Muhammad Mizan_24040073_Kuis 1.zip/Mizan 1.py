'''Kautsar Muhammad Mizan
RPL 1C
2404073'''
nilai = {90,86,57,59,95,77,67,94,82,86}
urut = (input("Masukkan no urut: "))
if urut== "1": print(90)
if urut== "2": print(86)
if urut== "3": print(57)
if urut== "4": print(59)
if urut== "5": print(95)
if urut== "6": print(77)
if urut== "7": print(67)
if urut== "8": print(94)
if urut== "9": print(82)
if urut== "10": print(86)
    