'''Kautsar Muhammad Mizan
RPL 1C
2404073'''
panjang = 80
lebar = 32
keliling = panjang*2 + lebar*2
lari = 5
jalan = 2*2
jarakTempuh = keliling*(lari+jalan)
konversi = jarakTempuh/1000
print (konversi, "KM")