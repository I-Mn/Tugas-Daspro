'''Kautsar Muhammad Mizan
RPL 1C
2404073'''
menit = 10
detik = 48
konversi = menit*60 + detik
print(konversi, "detik")