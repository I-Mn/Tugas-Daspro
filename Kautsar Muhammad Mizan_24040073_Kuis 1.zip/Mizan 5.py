'''Kautsar Muhammad Mizan
RPL 1C
2404073'''
panjang = 8
lebar = 1
tinggi = 4
harga = 520000
luas = 2*(panjang*tinggi) + 2*(lebar*tinggi)
biaya = (luas*harga)
print ("Biaya total adalah Rp.",biaya)