'''Kautsar Muhammad Mizan
RPL 1C
2404073'''
Juli = ("T-Shirt", "Blouse", "Kemeja", "Celana Panjang", "Rok", "Baju Renang", "Tas", "Topi", "Sepatu", "Sendal")
Agustus = ("T-Shirt", "Blouse", "Kemeja", "Celana Panjang", "Rok", "Gamis", "Tas", "Topi", "Sepatu", "Sendal", "Ikat rambut", "Kerudung")
print ("Jenis barang: ",(Juli), ". Jumlah jenis barang: ", (len(Juli)))
print ("Jenis barang: ",(Agustus), ". Jumlah jenis barang: ", (len(Agustus)))